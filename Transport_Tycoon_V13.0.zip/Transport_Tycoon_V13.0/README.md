# Transport Tycoon — V10.0 + V7.0 (Sauvegarde, fast-forward et modes)

Objectif : rattraper la V7 sautée (bus/tram/métro/infrastructures), posée
par-dessus la V9.1 (scénarios + vitesse x1000) sans réécriture de
l'existant.

## Constat de départ (audit)
Un seul type de véhicule existait, avec des constantes plates
(`DEFAULT_VEHICLE_CAPACITY`, `ADD_VEHICLE_COST`, `VEHICLE_OPEX_PER_HOUR`).

## Ajouts V7.0

### Catalogue de modes (`VEHICLE_MODES` dans `vehicles.js`)
| Mode   | Capacité | Coût véhicule | Opex/h | Résistance congestion |
|--------|---------:|---------------:|-------:|------------------------|
| Bus    | 35       | 3 000 €        | 12 €   | 0 (subit tout)         |
| Tram   | 70       | 9 000 €        | 22 €   | 0,5 (voie partagée prioritaire) |
| Métro  | 160      | 25 000 €       | 45 €   | 1 (grade-séparé, immunisé) |

**Le mode bus reprend exactement les anciennes constantes** : toute ligne
créée sans préciser de mode (`finishLine(state, log, routeLine)`, comme le
faisaient tous les tests jusqu'ici) se comporte à l'identique de la V9.1 —
vérifié, aucun des 11 tests précédents n'a été modifié.

### Infrastructure
Créer une ligne tram/métro ajoute un coût d'infrastructure unique
(voie/tunnel, proportionnel à la longueur de ligne) en plus du coût
routier existant (V2.2) — 0 € pour un bus, qui utilise les routes
existantes.

### Congestion (lien avec la V3.0)
La résistance du mode atténue la congestion subie :
`vehicle.congestion = 1 - (1 - congestionRoute) × (1 - résistance)`.
À résistance 0 (bus), c'est **exactement** l'ancienne formule. À résistance
1 (métro), la congestion n'a plus aucun effet — cohérent avec un métro
grade-séparé.

**Simplification assumée** : il n'existe pas de couche réseau séparée par
mode (pas de "voie ferrée" distincte des routes) — un métro compte quand
même dans le nombre de véhicules partageant un tronçon pour calculer la
congestion des *autres* véhicules, même s'il y est lui-même insensible.
Modéliser une infrastructure réellement distincte serait allé bien
au-delà du périmètre raisonnable de ce rattrapage.

### Économie et fréquence
`buyVehicleForLine`/`lineOperatingCost` utilisent le coût/opex du mode de
la ligne au lieu des anciennes constantes plates.

### Interface
- Sélecteur Bus/Tram/Métro à la création de ligne.
- Mode et coût du véhicule supplémentaire affichés par ligne.

## Tests
- Suite existante (V2.3 → V9.1) : inchangée, toujours verte.
- Nouveau `tests/v7-modes.mjs` : rétrocompatibilité bus par défaut, surcoût
  d'infrastructure du métro, capacité/coût d'achat par mode, résistance à
  la congestion (bus ralenti, métro immunisé sur le même tronçon partagé).

## Lancer
`launch-windows.bat` ou `launch-termux.sh` (le `file://` direct ne
fonctionne pas — modules ES bloqués).

## Prochaine étape logique
V10 — Méta-jeu/finition (sauvegardes, statistiques, équilibrage), qui
profiterait maintenant à la fois des scénarios (V9.0) et des modes de
transport (V7.0).


## V10.0

- Sauvegarde locale versionnée (`localStorage`).
- Reprise déterministe grâce à l’état du RNG.
- Les `Set`/`Map` des travaux routiers sont sérialisés explicitement.
- Demande intégrée sur le temps réellement simulé, y compris à 1000×.
- Durée des pannes exprimée en minutes simulées ; le champ `brokenTicksLeft`
  reste maintenu pour compatibilité.
- Statistiques supplémentaires : service de la demande et demande générée.
- Launcher Termux Android conservé (`launch-termux.sh`).

### Android / Termux

```bash
bash launch-termux.sh
```

Le script démarre un serveur HTTP local sur le port 8791 et ouvre
`http://localhost:8791` lorsqu’un outil `termux-open-url` est disponible.
